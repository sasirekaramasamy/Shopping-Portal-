package com.niit.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDao;
import com.niit.dao.SupplierDao;
import com.niit.model.Category;
import com.niit.model.Supplier;

@Controller
public class AdminController {

	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	SupplierDao supplierDao;

    @RequestMapping("/admin")
    public String admin(Model model, Principal principal) {
        User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = user.getUsername();
        System.out.println("spring-security,username:"+name);
        String password=user.getPassword();
        System.out.println("spring-security,password:"+password);
//        if(name.equals("67") && (password.equals("123"))){
        if(name.equals("67")){
        	return "redirect:/fetchCategorySupplier";
        }
        /*String loggedInUserName = principal.getName();
        model.addAttribute("user", loggedInUserName);
        model.addAttribute("name", "Spring Security Custom Login Demo");
        model.addAttribute("description", "Protected page !");*/
        return "admin";
    }

	//Fetch all categories & supplier
	  @RequestMapping(value = "/fetchCategorySupplier", method = RequestMethod.GET)
	  public String fetchAllCategoriesAndSuppliers(Model model) 
	  {
		  
//		  Fetch all categories
		  Category category=new Category();
		  List<Category> categoryList=null;			 			  
		  categoryList=categoryDao.getAllCategories();
		  for(int i=0;i<categoryList.size();i++) {
			  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
		  }
		  category.setCategoryList(categoryList);
		  model.addAttribute("category",category);

			//Fetch all suppliers
		  Supplier supplier=new Supplier();
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  
		  supplier.setSupplierList(supplierList);
		  model.addAttribute("supplier",supplier);
		  
		  
	        return "admin";

	  }

	
	/*
	
	//Fetch all categories & supplier
	  @RequestMapping(value = "/fetchCategorySupplier", method = RequestMethod.GET)
	  public String fetchAllCategoriesAndSuppliers(Model model) {
		  
//		  Fetch all categories
		  List<Category> categoryList=null;			 			  
		  categoryList=categoryDao.getAllCategories();
		  for(int i=0;i<categoryList.size();i++) {
			  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
		  }
		  model.addAttribute("categoryList",categoryList);

			//Fetch all suppliers
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  model.addAttribute("supplierList",supplierList);
		  
	  return "admin";
	  }
	  */
}
