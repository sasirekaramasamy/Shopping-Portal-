package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.CategoryDao;
import com.niit.dao.SupplierDao;
import com.niit.model.Category;
import com.niit.model.Supplier;

@Controller
public class AdminController {

	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	SupplierDao supplierDao;
	
	//Fetch all categories & supplier
	  @RequestMapping(value = "/fetchCategorySupplier", method = RequestMethod.GET)
	  public String fetchAllCategoriesAndSuppliers(Model model) {
		  
//		  Fetch all categories
		  List<Category> categoryList=null;			 			  
		  categoryList=categoryDao.getAllCategories();
		  for(int i=0;i<categoryList.size();i++) {
			  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
		  }
		  model.addAttribute("categoryList",categoryList);

			//Fetch all suppliers
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  model.addAttribute("supplierList",supplierList);
		  
	  return "admin";
	  }
	  
		
	  @RequestMapping(value = "/fetchSuppliers", method = RequestMethod.GET)
	  public String fetchAllSuppliers(Model model) {
		  
	  return "admin";
	  }

}
