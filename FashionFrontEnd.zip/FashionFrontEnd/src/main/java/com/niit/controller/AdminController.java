package com.niit.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDao;
import com.niit.dao.SupplierDao;
import com.niit.model.Category;
import com.niit.model.Supplier;

@Controller
public class AdminController {

	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	SupplierDao supplierDao;


	//Fetch all categories & supplier
	  @RequestMapping(value = "/fetchCategorySupplier", method = RequestMethod.GET)
	  public String fetchAllCategoriesAndSuppliers(Model model) 
	  {
		  
//		  Fetch all categories
		  Category category=new Category();
		  List<Category> categoryList=null;			 			  
		  categoryList=categoryDao.getAllCategories();
		  for(int i=0;i<categoryList.size();i++) {
			  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
		  }
		  category.setCategoryList(categoryList);
		  model.addAttribute("category",category);

			//Fetch all suppliers
		  Supplier supplier=new Supplier();
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  
		  supplier.setSupplierList(supplierList);
		  model.addAttribute("supplier",supplier);
		  
	        return "admin";

	  }

	
	/*
	
	//Fetch all categories & supplier
	  @RequestMapping(value = "/fetchCategorySupplier", method = RequestMethod.GET)
	  public String fetchAllCategoriesAndSuppliers(Model model) {
		  
//		  Fetch all categories
		  List<Category> categoryList=null;			 			  
		  categoryList=categoryDao.getAllCategories();
		  for(int i=0;i<categoryList.size();i++) {
			  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
		  }
		  model.addAttribute("categoryList",categoryList);

			//Fetch all suppliers
		  List<Supplier> supplierList=null;			 			  
		  supplierList=supplierDao.getAllSuppliers();
		  for(int i=0;i<supplierList.size();i++) {
			  System.out.println("SUPPLIER DETAILS :"+(Supplier)supplierList.get(i));
		  }
		  model.addAttribute("supplierList",supplierList);
		  
	  return "admin";
	  }
	  */
}
