package com.niit.controller;

import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.Iterator;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolationException;

import org.hibernate.collection.internal.PersistentSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CartDao;
import com.niit.dao.ProductDao;
import com.niit.model.Cart;
import com.niit.model.Product;
import com.niit.model.User;


@Controller

public class CartController {
	
	@Autowired
	private CartDao cartDao;

	@Autowired
	private ProductDao productDao;
	
	
	@RequestMapping("/viewCart")
	public ModelAndView showCart(@RequestParam(name = "result", required = false) String result) {
		
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String username = loggedInUser.getName();
		System.out.println("view cart, user:"+username);
		
		ModelAndView mv = new ModelAndView("page");
		if (result != null) {
			switch (result) {
			case "updated":
				mv.addObject("message", "Cart has been updated successfully!");
				break;
			case "added":
				mv.addObject("message", "Cart has been added successfully!");
				break;
			case "deleted":
				mv.addObject("message", "Cart has been removed successfully!");
				break;
			case "error":
				mv.addObject("message", "Something went wrong!");
				break;
			}
		}
		mv.addObject("title", "User Cart");
		mv.addObject("userClickShowCart", true);
		mv.addObject("cart", cartDao.getCartItems(username));
		return mv;
	}

	@RequestMapping(value="/updateCart/{cartid}")
	public String updateToCart(@PathVariable int cartid) {
									
			
				return "";
			


	}

	@RequestMapping("/{id}/delete")
	public String deleteCart(@PathVariable int id,@ModelAttribute("cart")Cart cart) {
		boolean response = cartDao.deleteCartItem(cart);
		return "redirect:/cart/show?" + response;

	}
	
	@RequestMapping("/addToCart/{pid}")
		public String addCart(@PathVariable int pid,HttpServletRequest request,HttpSession session) {

		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String username = loggedInUser.getName();
		System.out.println("user:"+username);

		System.out.println("path variable:"+pid);
		request.getSession().getAttribute("user");
		boolean response;
			Product product=productDao.getProductById(pid);
			Cart cart=new  Cart();			
			
			User user= cart.getUser();
			if(user==null) {
				user=new User();
				user.setId(Integer.parseInt(username));
				cart.setUser(user);
			}
			cart.setProductId(product.getProductId());
			Double total=cart.getGrandTotal()+product.getProductPrice();
			cart.setGrandTotal(total);
			
			List<Cart> carts=cartDao.getAllCart();						
			System.out.println("carts:"+carts+carts.isEmpty());
			int flag=0;
			if(!carts.isEmpty()) {
			for(Cart cartObject:carts) {
				
				Set<Product> products=cartObject.getProducts();
				
				if (pid==cartObject.getProductId()) {
					Model model;
					flag=1;
//					return "redirect:/updateCart?"+cartObject.getCartId();
					
					
					int quantity = cartObject.getQuantity();
					Double totalUpdate=cartObject.getGrandTotal()+product.getProductPrice();
					cartObject.setGrandTotal(totalUpdate);
					quantity++;
					cartObject.setQuantity(quantity);
					products.add(product);
					cart.setProducts(products);
					System.out.println("UPDATE CART DETAILS:" + cartObject);

					try {
					response = cartDao.update(cartObject);
					}
					catch(DataIntegrityViolationException ex) {
						ex.getMessage();
					}
					

				}
				
			}
			if(flag==0) {
				Set<Product> products=cart.getProducts();
				products.add(product);
				cart.setProducts(products);
				System.out.println("CART DETAILS:" + cart);
				response = cartDao.addToCart(cart);
				
				return "redirect:/showAllProducts";

			}
			}
			 else {
					Set<Product> products=cart.getProducts();
					products.add(product);
					cart.setProducts(products);
					System.out.println("CART DETAILS:" + cart);
					response = cartDao.addToCart(cart);
				}
			
	
		
			//			return "redirect:/viewCart?"+cart.getCartId();
			return "redirect:/showAllProducts";
			
		}
}