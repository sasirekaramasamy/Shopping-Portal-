package com.niit.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CategoryDao;
import com.niit.dao.SupplierDao;
import com.niit.dao.UserDao;
import com.niit.model.Category;
import com.niit.model.Supplier;
import com.niit.model.User;

@Controller
public class CategoryController {	
		
		@Autowired
		private CategoryDao categoryDao;
		
		@Autowired
		private SupplierDao supplierDao;

		// Category UI
		@RequestMapping(value = "/category" )
		public ModelAndView categoryPage() {
			ModelAndView mv = new ModelAndView("page");
			mv.addObject("userClickCategory", true);
			System.out.println("inside category controller viewCategory method..");
			return mv;
		}
			/*	
		//Insert category into Database		
		  @RequestMapping( value = "/categoryProcess", method = RequestMethod.POST)
		  public ModelAndView addCategory(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("category") Category category) {
			  			 
			  System.out.println("CATEGORY DETAILS :"+category);
			  categoryDao.save(category);
			  
		  return new ModelAndView("welcome");
		  }
		  */
			//Edit category 		
		  @RequestMapping(value="/categoryProcess", method = RequestMethod.POST)
		  public ModelAndView editCategory(@RequestParam String action,@ModelAttribute("category") Category category) {
			  
			  ModelAndView mv = new ModelAndView("page");			  
			  
			  if(action.equals("Edit")){

			  System.out.println("EDIT,CATEGORY DETAILS :"+category);
			  boolean result=categoryDao.update(category);
			  System.out.println("CATEGORY EDIT:"+result);
			  }
			  else if(action.equals("Save")){
				  System.out.println("SAVE, CATEGORY DETAILS :"+category);
				  categoryDao.save(category);
			  }
			  else if(action.equals("Delete")){
				  System.out.println("DELETE, CATEGORY DETAILS :"+category);
				  boolean result=categoryDao.delete(category);
				  System.out.println("CATEGORY DELETE:"+result);
			  }
			  else {
				  
			  }
			  
			  Supplier supplier=new Supplier();
			  List<Supplier> supplierList=null;			 			  
			  supplierList=supplierDao.getAllSuppliers();
			  supplier.setSupplierList(supplierList);
			  System.out.println("category, supplier list:"+supplierList);

			  
			  List<Category> categoryList=null;			 			  
			  categoryList=categoryDao.getAllCategories();
			  category.setCategoryList(categoryList);
			  System.out.println("category, category list:"+categoryList);
			  
			  mv.addObject("supplier",supplier);
			  mv.addObject("category",category);
			  mv.addObject("userClickCategory", true);
			  
		  return mv;
		  }
		
		/*
		  
			//Fetch all categories		
		  @RequestMapping(value = "/fetchCategories", method = RequestMethod.GET)
		  public String fetchAllCategories(Model model) {
			  List<Category> categoryList=null;			 			  
			  categoryList=categoryDao.getAllCategories();
			  for(int i=0;i<categoryList.size();i++) {
				  System.out.println("CATEGORY DETAILS :"+(Category)categoryList.get(i));
			  }
			  model.addAttribute("categoryList",categoryList);
		  return "admin";
		  }

*/
}
