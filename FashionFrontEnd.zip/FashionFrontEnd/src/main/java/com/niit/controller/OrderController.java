package com.niit.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.CartDao;
import com.niit.dao.OrdersDao;
import com.niit.dao.UserDao;
import com.niit.model.Cart;
import com.niit.model.Orders;
import com.niit.model.User;

@Controller
public class OrderController {
	
	@Autowired
	private CartDao cartDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private OrdersDao ordersDao;

	@RequestMapping("/payment")
	public String paymentProcess()
	{
		return "";
	}
	
	@RequestMapping("/generateInvoice")
	public String generateOrderInvoice(Model model) {
		
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String userid = loggedInUser.getName();
		
		List<Cart> carts=cartDao.getCartItems(userid);
		User user = userDao.findById(Integer.parseInt(userid));
		
		Orders order=new Orders();
		order.setUsername(userid);
		order.setBillingAddress(user.getAddress());
		order.setOrderDate(new Date());		
		order.setCarts(carts);
		
		System.out.println("generating invoice:"+order);
		
		model.addAttribute("orders", order);
		
		return "invoice";
	}
	
	@RequestMapping("/showInvoice")
	public ModelAndView showOrderInvoice() {
		ModelAndView mv=new ModelAndView("page");
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String userid = loggedInUser.getName();
		System.out.println("show invoice, user:"+userid);
		mv.addObject("title", "Invoice");
		mv.addObject("userClickShowInvoice", true);
		mv.addObject("order", ordersDao.findById(Integer.parseInt(userid)));

		return mv;
	}
}
