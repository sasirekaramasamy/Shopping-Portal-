package com.niit.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.ProductDao;

import com.niit.model.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao productDao;
	
	//Insert product		
	  @RequestMapping(value = "/productProcess", method = RequestMethod.POST)
	  public String fetchAllProduct(@RequestParam String action,  @ModelAttribute("product")Product product) {		  
		  
		  if(action.equals("Edit")){

			  System.out.println("EDIT,PRODUCT DETAILS:"+product);
		  boolean result=productDao.update(product);
		  System.out.println("PRODUCT EDIT:"+result);
		  }
		  else if(action.equals("Save")){
			  System.out.println("PRODUCT DETAILS:"+product);
			  productDao.addProduct(product);
		  }
		  else if(action.equals("Delete")){
			  System.out.println("DELETE,PRODUCT DETAILS:"+product);
			  boolean result=productDao.delete(product);
			  System.out.println("PRODUCT DELETE:"+result);
		  }
		  else {
			  
		  }


	  return "welcome";
	  }
}
