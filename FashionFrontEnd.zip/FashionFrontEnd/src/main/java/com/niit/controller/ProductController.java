package com.niit.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.ProductDao;

import com.niit.model.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao productDao;
	
	//Insert product		
	  @RequestMapping(value = "/productProcess", method = RequestMethod.POST)
	  public String fetchAllCategories(HttpServletRequest request, HttpServletResponse response,  @ModelAttribute("product")Product product) {
		  
		  System.out.println("PRODUCT DETAILS:"+product);
		  productDao.addProduct(product);
	  return "welcome";
	  }
}
