package com.niit.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.SupplierDao;
import com.niit.model.Category;
import com.niit.model.Supplier;

@Controller
public class SupplierController {

	@Autowired
	SupplierDao supplierDao;

	// Supplier UI
	@RequestMapping(value = "/supplier")
	public ModelAndView supplierPage() {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("userClickSupplier", true);
		System.out.println("inside supplier controller supplierPage method..");
		return mv;
	}

	// Insert supplier into Database
	@RequestMapping(value = "/supplierProcess", method = RequestMethod.POST)
	public ModelAndView addCategory(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("supplier") Supplier supplier) {
		System.out.println("SUPPLIER DETAILS :" + supplier);
		supplierDao.save(supplier);
		return new ModelAndView("viewSupplier");
	}

}
