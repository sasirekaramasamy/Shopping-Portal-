package com.niit.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Repository;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.niit.model.User;

@Repository("userValidator")
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {

		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object object, Errors error) {
		ValidationUtils.rejectIfEmpty(error, "username", "user.username.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "mobno", "user.mobno.empty");
		ValidationUtils.rejectIfEmpty(error, "email", "user.email.empty");
		ValidationUtils.rejectIfEmpty(error, "password", "user.password.empty");
		ValidationUtils.rejectIfEmpty(error, "address", "user.address.empty");

		User user = (User) object;

		if (user.getMobno() != null) {
			Pattern mobileNumberPattern = Pattern.compile("[0-9]{10}$");
			if (!mobileNumberPattern.matcher(Long.toString(user.getMobno())).matches()) {

				error.rejectValue("mobno", "user.mobno.invalid");
			}
		}

		if(!user.getEmail().equals("")) {
		Pattern emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
		if (!emailPattern.matcher(user.getEmail()).matches()) {

			error.rejectValue("email", "user.email.invalid");
		}
		}

	}

}
