package com.app;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.config.HibernateConfig;
import com.niit.dao.UserDao;
import com.niit.model.User;

/**
 * @author imssbora
 *
 */
public class MainApp {
   /**
 * @param args
 * @throws SQLException
 */
public static void main(String[] args) throws SQLException {
	   	   
      AnnotationConfigApplicationContext context = 
            new AnnotationConfigApplicationContext(HibernateConfig.class);

      //INSERTING USER BEAN OBJECT
      UserDao userDao=context.getBean(UserDao.class);
            // Add Users
      User user=new User();
      
      
      user.setUsername("sasi");
      user.setMobno(123);
      user.setAddress("ch");
      user.setEmail("sasi@gmail.com");
      user.setRole("role");
      user.setPassword("123");
      
      userDao.save(user);
      



      // Get Users
      List<User> users = userDao.getAllUsers();
      for (User userObj : users) {
         System.out.println("Id = "+userObj.getId());
         System.out.println("Name = "+userObj.getUsername());
         System.out.println("Address = "+userObj.getAddress());
         System.out.println("Email = "+userObj.getEmail());
         System.out.println();
      }

      context.close();
   }
}
