package com.app;

import java.sql.SQLException;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.config.HibernateConfig;
import com.model.User;
import com.service.UserService;

public class MainApp {
   public static void main(String[] args) throws SQLException {
	   	   
      AnnotationConfigApplicationContext context = 
            new AnnotationConfigApplicationContext(HibernateConfig.class);

      UserService userService = context.getBean(UserService.class);
            // Add Users
      userService.add(new User("Sunil", "Bora", "suni.bora@example.com","ch","123"));
      userService.add(new User("David", "Miller", "david.miller@example.com","blore","456"));
      

/*
      UserDao userDao = context.getBean(UserDao.class);

      // Add Users
      userDao.add(new User("Sunil", "Bora", "suni.bora@example.com"));
      userDao.add(new User("David", "Miller", "david.miller@example.com"));
      userDao.add(new User("Sameer", "Singh", "sameer.singh@example.com"));
      userDao.add(new User("Paul", "Smith", "paul.smith@example.com"));
*/
      
      // Get Users
      List<User> users = userService.listUsers();
      for (User user : users) {
    	  System.out.println("Email = "+user.getEmail());
         System.out.println("Name = "+user.getName());
         System.out.println("Password = "+user.getPassword());
         System.out.println("Address = "+user.getAddress());
         System.out.println("Phone = "+user.getPhone());
         System.out.println();
      }

      context.close();
   }
}
