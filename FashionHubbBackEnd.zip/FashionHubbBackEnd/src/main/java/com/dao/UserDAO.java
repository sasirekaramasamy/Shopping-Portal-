package com.dao;

import java.util.List;

import com.model.User;

public interface UserDAO {
    List<User> listUsers();
	public void addUser(User user);
}
