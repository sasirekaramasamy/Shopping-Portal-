package com.niit.dao;

import com.niit.model.Cart;

public interface CartProductDao {
	public boolean update(Cart cart);
}
