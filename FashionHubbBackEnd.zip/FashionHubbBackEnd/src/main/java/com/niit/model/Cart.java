package com.niit.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.Type;

@Entity
public class Cart implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cart_id")
	private Integer cartId;

	@Column(name = "grand_total")
	private Double grandTotal=0.0;

	@Column(name = "product_id")
	private Integer productId; 
	
	private Integer quantity=1;		
	
	
    @OneToMany(fetch=FetchType.EAGER)
//	@OneToMany
	@JoinTable(name = "CART_PRODUCT", indexes= {@Index(unique=false,columnList="cart_id,product_id")}, joinColumns = { @JoinColumn(name = "cart_id", unique=false) }, inverseJoinColumns = { @JoinColumn(name = "Product_Id",unique=false)})    
	private Set<Product> products=new HashSet<Product>();
	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}



	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public Integer getCartId() {
		return cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(Double grandTotal) {
		this.grandTotal = grandTotal;
	}


	
	
	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}




	// linking the cart with a user
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="user_Id")
	private User user;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Cart [id=" + cartId + ", grandTotal=" + grandTotal  + ", user=" + user + "]";
	}
	
	
	
	
}