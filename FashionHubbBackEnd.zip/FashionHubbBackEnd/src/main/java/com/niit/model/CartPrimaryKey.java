package com.niit.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CartPrimaryKey implements Serializable 
{

}
