package com.niit.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Category")
public class Category implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Category_Id")
	private int categoryId;
	@Column(name = "Category_Name", nullable = false)
	private String categoryName;
	
	// getters and setters
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}

	
	
	/*
	 * @OneToMany(targetEntity=Product.class, mappedBy="category") private
	 * Set<Product>product;
	 * 
	 * 
	 * public Set<Product> getProduct() { return product; } public void
	 * setProduct(Set<Product> product) { this.product = product; }
	 */
	
	
	
}
