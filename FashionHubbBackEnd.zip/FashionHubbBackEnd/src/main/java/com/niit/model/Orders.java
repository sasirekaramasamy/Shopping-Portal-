package com.niit.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Orders")
public class Orders implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Order_Id")
	private Integer orderid;
	@Column(name="Order_Date")
	private Date orderDate;
	@Column(name = "Product_Id")
	private Integer productid;
	@Column(name = "Payment_Status")
	private String paymentStatus;
	@Column(name = "User_Name")
	private String username;
	@Column(name="Billing_Address")
	private String billingAddress;
	@Column(name = "Total_Amount")
	private Double TotalAmount=0.0;
	@Column(name="Shipping_Amount")
	private Double shippingAmount;
	@Column(name="Shipping_Address")
	private String shippingAddress;
	@Column(name="Payment_Method")
	private String paymentMethod;
	
    @OneToMany(fetch=FetchType.EAGER)
//	@JoinTable(name = "CART_ORDER", joinColumns = { @JoinColumn(name = "order_id", unique=false) }, inverseJoinColumns = { @JoinColumn(name = "cart_id",unique=false)})
	@Column(name="carts")	
	private List<Cart> carts;
	
	// getters and setters		
	
	public Integer getOrderid() {
		return orderid;
	}
	public List<Cart> getCarts() {
		return carts;
	}
	public void setCarts(List<Cart> carts) {
		this.carts = carts;
	}
	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Integer getProductid() {
		return productid;
	}
	public void setProductid(Integer productid) {
		this.productid = productid;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public Double getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		TotalAmount = totalAmount;
	}
	public Double getShippingAmount() {
		return shippingAmount;
	}
	public void setShippingAmount(Double shippingAmount) {
		this.shippingAmount = shippingAmount;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	@Override
	public String toString() {
		return "Orders [orderid=" + orderid + ", orderDate=" + orderDate + ", productid=" + productid
				+ ", paymentStatus=" + paymentStatus + ", username=" + username + ", billingAddress=" + billingAddress
				+ ", TotalAmount=" + TotalAmount + ", shippingAmount=" + shippingAmount + ", shippingAddress="
				+ shippingAddress + ", paymentMethod=" + paymentMethod + "]";
	}		
	
	}
